import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModel, AutoModelForMaskedLM
from math import sqrt

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class ner_unit(nn.Module):
    def __init__(self, args, ner2idx, ner_hidden_size,share_hidden_size):
        super(ner_unit, self).__init__()

        self.ner2idx = ner2idx
        self.hid2hid = nn.Linear(ner_hidden_size * 2 + share_hidden_size, ner_hidden_size)
        self.hid2tag = nn.Linear(ner_hidden_size, len(ner2idx))
        self.elu = nn.ELU()
        self.ln = nn.LayerNorm(ner_hidden_size)
        self.dropout = nn.Dropout(args.dropout)



    def forward(self, h_ner, h_share, mask):
        length, batch_size, _ = h_ner.size()


        st = h_ner.unsqueeze(1).repeat(1, length, 1, 1)
        en = h_ner.unsqueeze(0).repeat(length, 1, 1, 1)

        ner = torch.cat((st, en, h_share), dim=-1)


        ner = self.ln(self.hid2hid(ner))
        ner = self.elu(self.dropout(ner))
        ner = torch.sigmoid(self.hid2tag(ner))

        diagonal_mask = torch.triu(torch.ones(batch_size, length, length)).to(device)
        diagonal_mask = diagonal_mask.permute(1, 2, 0)

        mask_s = mask.unsqueeze(1).repeat(1, length, 1)
        mask_e = mask.unsqueeze(0).repeat(length, 1, 1)

        mask_ner = mask_s * mask_e
        mask = diagonal_mask * mask_ner
        mask = mask.unsqueeze(-1).repeat(1, 1, 1, len(self.ner2idx))

        ner = ner * mask

        return ner

class re_unit(nn.Module):
    def __init__(self, args, re2idx,re_hidden_size,share_hidden_size):
        super(re_unit, self).__init__()
        self.relation_size = len(re2idx)
        self.re2idx = re2idx

        self.hid2hid = nn.Linear(re_hidden_size * 2+share_hidden_size, re_hidden_size)
        self.hid2rel = nn.Linear(re_hidden_size, self.relation_size)
        self.elu = nn.ELU()
        self.ln = nn.LayerNorm(re_hidden_size)

        self.dropout = nn.Dropout(args.dropout)



    def forward(self, h_re, h_share, mask):
        length, batch_size, _ = h_re.size()

        r1 = h_re.unsqueeze(1).repeat(1, length, 1, 1)
        r2 = h_re.unsqueeze(0).repeat(length, 1, 1, 1)

        re = torch.cat((r1, r2, h_share), dim=-1)

        re = self.ln(self.hid2hid(re))
        re = self.elu(self.dropout(re))
        re = torch.sigmoid(self.hid2rel(re))

        mask = mask.unsqueeze(-1).repeat(1, 1, self.relation_size)
        mask_e1 = mask.unsqueeze(1).repeat(1, length, 1, 1)
        mask_e2 = mask.unsqueeze(0).repeat(length, 1, 1, 1)
        mask = mask_e1 * mask_e2

        re = re * mask

        return re


class SelfAttention(nn.Module):
    def __init__(self, dim_q, dim_k, dim_v):
        super(SelfAttention, self).__init__()
        self.dim_q = dim_q
        self.dim_k = dim_k
        self.dim_v = dim_v

        # 定义线性变换函数
        self.linear_q = nn.Linear(dim_q, dim_k, bias=False)
        self.linear_k = nn.Linear(dim_q, dim_k, bias=False)
        self.linear_v = nn.Linear(dim_q, dim_v, bias=False)
        self._norm_fact = 1 / sqrt(dim_k)

    def forward(self, x):
        # x: batch, n, dim_q
        # 根据文本获得相应的维度

        batch, n, dim_q = x.shape
        assert dim_q == self.dim_q

        q = self.linear_q(x)  # batch, n, dim_k
        k = self.linear_k(x)  # batch, n, dim_k
        v = self.linear_v(x)  # batch, n, dim_v
        # q*k的转置 并*开根号后的dk
        dist = torch.bmm(q, k.transpose(1, 2)) * self._norm_fact  # batch, n, n
        # 归一化获得attention的相关系数
        dist = torch.softmax(dist, dim=-1)  # batch, n, n
        # attention系数和v相乘，获得最终的得分
        att = torch.bmm(dist, v)
        return att


class ConvAttentionLayer(nn.Module):
    def __init__(self, hid_dim, n_heads, pre_channels, channels, groups, dropout=0.1):
        super(ConvAttentionLayer, self).__init__()
        assert hid_dim % n_heads == 0
        self.n_heads = n_heads
        input_channels = hid_dim * 2 + pre_channels
        self.groups = groups

        self.activation = nn.LeakyReLU(negative_slope=0.1, inplace=True)

        self.linear1 = nn.Linear(hid_dim, hid_dim, bias=False)
        self.linear2 = nn.Linear(hid_dim, hid_dim, bias=False)

        self.conv = nn.Sequential(
            nn.Dropout2d(dropout),
            nn.Conv2d(input_channels, channels, kernel_size=1),
            nn.LeakyReLU(negative_slope=0.1, inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1),
            nn.LeakyReLU(negative_slope=0.1, inplace=True),
        )
        self.score_layer = nn.Conv2d(channels, n_heads, kernel_size=1, bias=False)

        self.dropout = nn.Dropout(dropout)

    def forward(self, x, y, pre_conv=None, mask=None, residual=True, self_loop=True):
        ori_x, ori_y = x, y

        B, M, _ = x.size()
        B, N, _ = y.size()

        fea_map = torch.cat([x.unsqueeze(2).repeat_interleave(N, 2), y.unsqueeze(1).repeat_interleave(M, 1)],
                            -1).permute(0, 3, 1, 2).contiguous()
        if pre_conv is not None:
            fea_map = torch.cat([fea_map, pre_conv], 1)
        fea_map = self.conv(fea_map)

        scores = self.activation(self.score_layer(fea_map))

        if mask is not None:
            mask = mask.expand_as(scores)
            scores = scores.masked_fill(mask.eq(0), -9e10)

        x = self.linear1(self.dropout(x))
        y = self.linear2(self.dropout(y))
        out_x = torch.matmul(F.softmax(scores, -1), y.view(B, N, self.n_heads, -1).transpose(1, 2))
        out_x = out_x.transpose(1, 2).contiguous().view(B, M, -1)
        out_y = torch.matmul(F.softmax(scores.transpose(2, 3), -1), x.view(B, M, self.n_heads, -1).transpose(1, 2))
        out_y = out_y.transpose(1, 2).contiguous().view(B, N, -1)

        if self_loop:
            out_x = out_x + x
            out_y = out_y + y

        out_x = self.activation(out_x)
        out_y = self.activation(out_y)

        if residual:
            out_x = out_x + ori_x
            out_y = out_y + ori_y
        return out_x, out_y, fea_map


class ConvAttention(nn.Module):
    def __init__(self, hid_dim, n_heads, pre_channels, channels, layers, groups, dropout):
        super(ConvAttention, self).__init__()

        self.layers = nn.ModuleList([ConvAttentionLayer(hid_dim, n_heads, pre_channels if i == 0 else channels,
                                                        channels, groups, dropout=dropout) for i in range(layers)])

    def forward(self, x, y, fea_map=None, mask=None, residual=True, self_loop=True):
        for layer in self.layers:
            x, y, fea_map = layer(x, y, fea_map, mask, residual, self_loop)

        return x, y, fea_map.permute(0, 2, 3, 1).contiguous()



class CARE(nn.Module):
    def __init__(self, args, input_size, ner2idx, rel2idx, em2idx):
        super(CARE, self).__init__()
        self.args = args

        self.ner = ner_unit(args, ner2idx,ner_hidden_size=args.hidden_size,share_hidden_size=args.share_hidden_size)
        self.re = re_unit(args, rel2idx,re_hidden_size=args.hidden_size,share_hidden_size=args.share_hidden_size)
        self.em = re_unit(args, em2idx, re_hidden_size=args.hidden_size, share_hidden_size=args.share_hidden_size)

        self.dropout = nn.Dropout(args.dropout)
        self.dist_emb = nn.Embedding(20, args.dist_emb_size)

        if args.embed_mode == 'bert_cased':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/bert")
            self.bert = AutoModel.from_pretrained("pretrained/bert")
        elif args.embed_mode == 'scibert_cased':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/scibert",do_lower_case=False)
            self.bert = AutoModel.from_pretrained("pretrained/scibert")
        elif args.embed_mode == 'bert_chinese':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/bert_chinese")
            self.bert = AutoModelForMaskedLM.from_pretrained("pretrained/bert_chinese")


        self.conv_attention = ConvAttention(hid_dim=args.hidden_size, n_heads=1, pre_channels=args.dist_emb_size, channels=args.share_hidden_size, groups=1, layers=args.co_attention_layers, dropout=args.dropout)


    def forward(self, x, mask, dist):
        # print(x)
        x = self.tokenizer(x, return_tensors="pt",
                                  padding='longest',
                                  is_split_into_words=True).to(device)

        x = self.bert(**x)[0]
        # print("x",x)

        if self.training:
            x = self.dropout(x)
        new_linear_layer = nn.Linear(21128, 768).to(device)

        # 应用新的线性层到BERT的输出上
        x = new_linear_layer(x)

        length = x.size(1)
        dist = self.dist_emb(dist).permute(0,3,1,2)


        padding_mask = mask.unsqueeze(-1)
        mask1 = padding_mask.unsqueeze(1).repeat(1, length, 1, 1)
        mask2 = padding_mask.unsqueeze(0).repeat(length, 1, 1, 1)
        padding_mask = mask1 * mask2

        padding_mask = padding_mask.permute(2,3,0,1)

        h_ner, h_re, h_share = self.conv_attention(x, x, dist, padding_mask)
        h_ner, h_em, h_share_em = self.conv_attention(x, x, dist, padding_mask)
        h_ner = h_ner.permute(1,0,2)

        h_re = h_re.permute(1,0,2)
        h_em = h_em.permute(1, 0, 2)
        h_share = h_share.permute(1,2,0,3)
        h_share_em = h_share_em.permute(1, 2, 0, 3)

        ner_score_em = self.ner(h_ner, h_share_em, mask)
        ner_score = self.ner(h_ner, h_share, mask)
        re_core = self.re(h_re, h_share, mask)
        em_score = self.em(h_em, h_share_em, mask)
        return ner_score, ner_score_em, re_core ,em_score

class CARE_en(nn.Module):
    def __init__(self, args, input_size, ner2idx, rel2idx, em2idx):
        super(CARE_en, self).__init__()
        self.args = args

        self.ner = ner_unit(args, ner2idx,ner_hidden_size=args.hidden_size,share_hidden_size=args.share_hidden_size)
        self.re = re_unit(args, rel2idx,re_hidden_size=args.hidden_size,share_hidden_size=args.share_hidden_size)
        self.em = re_unit(args, em2idx, re_hidden_size=args.hidden_size, share_hidden_size=args.share_hidden_size)

        self.dropout = nn.Dropout(args.dropout)
        self.dist_emb = nn.Embedding(20, args.dist_emb_size)

        if args.embed_mode == 'bert_cased':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/bert")
            self.bert = AutoModel.from_pretrained("pretrained/bert")
        elif args.embed_mode == 'scibert_cased':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/scibert",do_lower_case=False)
            self.bert = AutoModel.from_pretrained("pretrained/scibert")
        elif args.embed_mode == 'bert_chinese':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/bert_chinese")
            self.bert = AutoModelForMaskedLM.from_pretrained("pretrained/bert_chinese")


        self.conv_attention = ConvAttention(hid_dim=args.hidden_size, n_heads=1, pre_channels=args.dist_emb_size, channels=args.share_hidden_size, groups=1, layers=args.co_attention_layers, dropout=args.dropout)


    def forward(self, x, mask, dist):
        x = self.tokenizer(x, return_tensors="pt",
                           padding='longest',
                           is_split_into_words=True).to(device)
        x = self.bert(**x)[0]

        if self.training:
            x = self.dropout(x)

        length = x.size(1)
        dist = self.dist_emb(dist).permute(0,3,1,2)


        padding_mask = mask.unsqueeze(-1)
        mask1 = padding_mask.unsqueeze(1).repeat(1, length, 1, 1)
        mask2 = padding_mask.unsqueeze(0).repeat(length, 1, 1, 1)
        padding_mask = mask1 * mask2

        padding_mask = padding_mask.permute(2,3,0,1)

        h_ner, h_re, h_share = self.conv_attention(x, x, dist, padding_mask)
        h_ner, h_em, h_share_em = self.conv_attention(x, x, dist, padding_mask)
        h_ner = h_ner.permute(1,0,2)

        h_re = h_re.permute(1,0,2)
        h_em = h_em.permute(1, 0, 2)
        h_share = h_share.permute(1,2,0,3)
        h_share_em = h_share_em.permute(1, 2, 0, 3)

        ner_score_em = self.ner(h_ner, h_share_em, mask)
        ner_score = self.ner(h_ner, h_share, mask)
        re_core = self.re(h_re, h_share, mask)
        em_score = self.em(h_em, h_share_em, mask)
        return ner_score, ner_score_em, re_core ,em_score


class CARE_en_self(nn.Module):
    def __init__(self, args, input_size, ner2idx, rel2idx, em2idx):
        super(CARE_en_self, self).__init__()
        self.args = args

        self.ner = ner_unit(args, ner2idx,ner_hidden_size=args.hidden_size,share_hidden_size=args.share_hidden_size)
        self.re = re_unit(args, rel2idx,re_hidden_size=args.hidden_size,share_hidden_size=args.share_hidden_size)
        self.em = re_unit(args, em2idx, re_hidden_size=args.hidden_size, share_hidden_size=args.share_hidden_size)

        self.dropout = nn.Dropout(args.dropout)
        self.dist_emb = nn.Embedding(20, args.dist_emb_size)

        if args.embed_mode == 'bert_cased':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/bert")
            self.bert = AutoModel.from_pretrained("pretrained/bert")
        elif args.embed_mode == 'scibert_cased':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/scibert",do_lower_case=False)
            self.bert = AutoModel.from_pretrained("pretrained/scibert")
        elif args.embed_mode == 'bert_chinese':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/bert_chinese")
            self.bert = AutoModelForMaskedLM.from_pretrained("pretrained/bert_chinese")


        self.conv_attention = ConvAttention(hid_dim=args.hidden_size, n_heads=1, pre_channels=args.dist_emb_size, channels=args.share_hidden_size, groups=1, layers=args.co_attention_layers, dropout=args.dropout)
        self.self_attention = nn.MultiheadAttention(embed_dim=args.hidden_size, num_heads=8, dropout=args.dropout)

    def forward(self, x, mask, dist):
        x = self.tokenizer(x, return_tensors="pt",
                           padding='longest',
                           is_split_into_words=True).to(device)
        x = self.bert(**x)[0]

        if self.training:
            x = self.dropout(x)


        mask_2d = mask.squeeze(1).squeeze(-1)  # 从(batch_size, 1, seq_length, 1)变为(batch_size, seq_length)

        # 添加自注意力层
        self_attention_output, _ = self.self_attention(x, x, x, key_padding_mask=mask_2d)
        x = self.dropout(self_attention_output)


        length = x.size(1)
        dist = self.dist_emb(dist).permute(0,3,1,2)
        padding_mask = mask.unsqueeze(-1)
        mask1 = padding_mask.unsqueeze(1).repeat(1, length, 1, 1)
        mask2 = padding_mask.unsqueeze(0).repeat(length, 1, 1, 1)
        padding_mask = mask1 * mask2

        padding_mask = padding_mask.permute(2,3,0,1)

        h_ner, h_re, h_share = self.conv_attention(x, x, dist, padding_mask)
        h_ner, h_em, h_share_em = self.conv_attention(x, x, dist, padding_mask)

        # if self.training or mask is None:
        #     attn_mask = None
        # else:
        #     attn_mask = mask_2d.unsqueeze(1).unsqueeze(2)
        #     # 应用自注意力
        # attn_ner, _ = self.self_attention(h_ner, h_ner, h_ner, attn_mask=attn_mask)
        # h_ner = self.dropout(attn_ner)
        # attn_re, _ = self.self_attention(h_re, h_re, h_re, attn_mask=attn_mask)
        # h_re = self.dropout(attn_re)
        # attn_em, _ = self.self_attention(h_em, h_em, h_em, attn_mask=attn_mask)
        # h_em = self.dropout(attn_em)


        h_ner = h_ner.permute(1,0,2)
        h_re = h_re.permute(1,0,2)
        h_em = h_em.permute(1, 0, 2)
        h_share = h_share.permute(1,2,0,3)
        h_share_em = h_share_em.permute(1, 2, 0, 3)

        ner_score_em = self.ner(h_ner, h_share_em, mask)
        ner_score = self.ner(h_ner, h_share, mask)
        re_core = self.re(h_re, h_share, mask)
        em_score = self.em(h_em, h_share_em, mask)
        return ner_score, ner_score_em, re_core ,em_score

class CARE_en_deep(nn.Module):
    def __init__(self, args, input_size, ner2idx, rel2idx, em2idx):
        super(CARE_en_deep, self).__init__()
        self.args = args

        self.ner = ner_unit(args, ner2idx,ner_hidden_size=args.hidden_size,share_hidden_size=args.share_hidden_size)
        self.re = re_unit(args, rel2idx,re_hidden_size=args.hidden_size,share_hidden_size=args.share_hidden_size)
        self.em = re_unit(args, em2idx, re_hidden_size=args.hidden_size, share_hidden_size=args.share_hidden_size)

        self.dropout = nn.Dropout(args.dropout)
        self.dist_emb = nn.Embedding(20, args.dist_emb_size)

        if args.embed_mode == 'bert_cased':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/bert")
            self.bert = AutoModel.from_pretrained("pretrained/bert")
        elif args.embed_mode == 'scibert_cased':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/scibert",do_lower_case=False)
            self.bert = AutoModel.from_pretrained("pretrained/scibert")
        elif args.embed_mode == 'bert_chinese':
            self.tokenizer = AutoTokenizer.from_pretrained("pretrained/bert_chinese")
            self.bert = AutoModelForMaskedLM.from_pretrained("pretrained/bert_chinese")


        self.conv_attention = ConvAttention(hid_dim=args.hidden_size, n_heads=1, pre_channels=args.dist_emb_size, channels=args.share_hidden_size, groups=1, layers=args.co_attention_layers, dropout=args.dropout)
        self.self_attention = nn.MultiheadAttention(embed_dim=args.hidden_size, num_heads=8, dropout=args.dropout)

    def forward(self, x, mask, dist):
        x = self.tokenizer(x, return_tensors="pt",
                           padding='longest',
                           is_split_into_words=True).to(device)
        x = self.bert(**x)[0]

        if self.training:
            x = self.dropout(x)


        mask_2d = mask.squeeze(1).squeeze(-1)  # 从(batch_size, 1, seq_length, 1)变为(batch_size, seq_length)
        # print(mask_2d.shape)
        # 添加自注意力层
        self_attention_output, _ = self.self_attention(x, x, x, key_padding_mask=mask_2d)
        x = self.dropout(self_attention_output)


        length = x.size(1)
        dist = self.dist_emb(dist).permute(0,3,1,2)
        padding_mask = mask.unsqueeze(-1)
        mask1 = padding_mask.unsqueeze(1).repeat(1, length, 1, 1)
        mask2 = padding_mask.unsqueeze(0).repeat(length, 1, 1, 1)
        padding_mask = mask1 * mask2

        padding_mask = padding_mask.permute(2,3,0,1)

        h_ner_1, h_re, h_share = self.conv_attention(x, x, dist, padding_mask)
        h_ner_2, h_em, h_share_em = self.conv_attention(x, x, dist, padding_mask)
        h_re_2, h_em_2, h_share_em_2 = self.conv_attention(h_re, h_em, dist, padding_mask)

        # if self.training or mask is None:
        #     attn_mask = None
        # else:
        #     attn_mask = mask_2d.unsqueeze(1).unsqueeze(2)
        #     # 应用自注意力
        # attn_ner, _ = self.self_attention(h_ner, h_ner, h_ner, attn_mask=attn_mask)
        # h_ner = self.dropout(attn_ner)
        # attn_re, _ = self.self_attention(h_re, h_re, h_re, attn_mask=attn_mask)
        # h_re = self.dropout(attn_re)
        # attn_em, _ = self.self_attention(h_em, h_em, h_em, attn_mask=attn_mask)
        # h_em = self.dropout(attn_em)

        h_ner = h_ner_2 + h_ner_1

        h_ner = h_ner.permute(1,0,2)
        h_re_2 = h_re_2.permute(1,0,2)
        h_em_2 = h_em_2.permute(1, 0, 2)
        h_share = h_share.permute(1,2,0,3)
        h_share_em = h_share_em.permute(1, 2, 0, 3)
        h_share_em_2 = h_share_em_2.permute(1, 2, 0, 3)
        # ner_score_em = self.ner(h_ner, h_share_em, mask)
        ner_score = self.ner(h_ner, h_share+h_share_em, mask)

        re_core = self.re(h_re_2, h_share_em_2, mask)
        em_score = self.em(h_em_2, h_share_em_2, mask)
        return ner_score, re_core ,em_score

